TIC TAC TOE 3D (Freeware and Open Source, GNU) Version 1.1.

1-AUTHOR

  Jos� Lauro Strapasson. Quatro Barras, Paran�, Brazil.
  Email: jolauro@terra.com.br, jstrapasson@unicentro.br
  Web Site: http://joselauro.com or http://www.joselauro.cjb.net  

2-THANKS

  God.
  Stan Arts from Holland. (for tell me how 3D works)

3-REQUIREMENTS

  You must use at least a PC with Windows 95, 800X600 of resolution and at least 16 colors.
  In my Celeron 433Mhz with Windows 98 the program is slow but works fine.

4-HOW TO PLAY.

  To play in a position use 1..9 keys.
  To make the program plays use g (or G).
  To change between X and O use x (or X) and o (or O) (only in the begin).
  To start a new game use n (or N).
  To quit use q (or Q).

OBS:  It is normal to become slow when there are many pieces in the board.
      In a slow computer can be some beeps.

OBS2: When you start the program move the board up until disappears and then
      move far back to see the board in a more confortable angle.

	
5-ABOUT THE PROGRAM.

  Tic Tac Toe 3D version 1.1 was created using Ada 95 language with Gnat Compiler 
for Windows and JEWL graphical library.
  All 3D routines were created by my own with Stan Arts help and ideas.

6-VERSIONS.

 Version 1.0 relased on october 8th, 2002. (freeware with AdaGraph2000)
 Version 1.1 relased on november 26th , 2003. (GNU with JEWL)-Added filled polygons.
  
